module.exports = {
  secret: "maksym-secret-key",
};
