const authJwt = require("./authJwt");
const verifyRegister = require("./verifyRegister");

module.exports = {
  authJwt,
  verifyRegister
};
