import React from 'react'

const ChatWindow = () => {
    return (
        <div>
            Here is ChatWindow
        </div>
    )
}

export default ChatWindow