import React from 'react'

const ReportWindow = () => {
    return (
        <div>
            Here is ReportWindow
        </div>
    )
}

export default ReportWindow