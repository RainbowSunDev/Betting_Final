const printLog = async (err) => {
  console.error(err);
};
module.exports = { printLog };
