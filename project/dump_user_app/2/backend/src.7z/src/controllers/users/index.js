const checkUser = require("./checkRoomUser");

module.exports = {
  checkUser,
};
