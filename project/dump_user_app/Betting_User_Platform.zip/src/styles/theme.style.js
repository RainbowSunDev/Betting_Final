export const DEFAULT_SELECTED_BACK = "#6292b0";
export const DEFAULT_UNSELECTED_BACK = "#ededed";
export const DEFAULT_SELECTED_COLOR = "white";
export const DEFAULT_UNSELECTED_COLOR = "#898989";
export const DEFAULT_BACKGROUND_COLOR = "#f5f5f5";
