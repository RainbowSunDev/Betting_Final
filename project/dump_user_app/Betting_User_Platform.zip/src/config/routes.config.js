export const aboutRoutesConfig = {
  tabBarOptions: {
    upperCaseLabel: false,
    showIcon: false,
  },
  swipeEnabled: true,
  animationEnabled: true,
};
