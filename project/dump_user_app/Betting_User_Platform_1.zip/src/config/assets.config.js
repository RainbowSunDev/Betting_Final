export default {
    IMG_URL:'./assets'
}