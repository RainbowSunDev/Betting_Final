const withAuth = require('./withAuth');

module.exports = {
  withAuth,
};
